package handler

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/PriyanshuTrivedi/nexus-scheduler/code/api-gateway/client"
	"github.com/PriyanshuTrivedi/nexus-scheduler/code/api-gateway/middleware"
	"github.com/PriyanshuTrivedi/nexus-scheduler/code/api-gateway/util"
	bookingpb "github.com/PriyanshuTrivedi/nexus-scheduler/gen/idl/booking"
	identitypb "github.com/PriyanshuTrivedi/nexus-scheduler/gen/idl/identity"
	resourcepb "github.com/PriyanshuTrivedi/nexus-scheduler/gen/idl/resource"
	"google.golang.org/grpc/metadata"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

type Handler struct {
	Identity client.IdentityClient
	Resource client.ResourceClient
	Booking  client.BookingClient
	Issuer   *middleware.TokenIssuer
}

func New(i client.IdentityClient, r client.ResourceClient, b client.BookingClient, issuer *middleware.TokenIssuer) *Handler {
	return &Handler{
		Identity: i,
		Resource: r,
		Booking:  b,
		Issuer:   issuer,
	}
}
func decode(r *http.Request, msg proto.Message) error {
	b, err := io.ReadAll(r.Body)
	if err != nil {
		return err
	}
	return protojson.Unmarshal(b, msg)
}
func writeProto(w http.ResponseWriter, msg proto.Message) {
	b, e := protojson.MarshalOptions{UseProtoNames: true}.Marshal(msg)
	if e != nil {
		util.WriteJSON(w, map[string]string{"code": "INTERNAL", "message": e.Error()}, 500)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(b)
}
func call(w http.ResponseWriter, msg proto.Message, err error) {
	if err != nil {
		util.WriteGRPCError(w, err)
		return
	}
	writeProto(w, msg)
}
func meta(ctx *http.Request) context.Context {
	p, _ := middleware.PrincipalFromContext(ctx.Context())
	return metadata.AppendToOutgoingContext(ctx.Context(), "x-user-id", p.UserID, "x-user-role", roleName(p.Role), "x-org-id", p.OrgID, "x-tenant-type", tenantTypeName(p.TenantType))
}
func roleName(r identitypb.UserRole) string {
	switch r {
	case identitypb.UserRole_USER_ROLE_CLIENT:
		return "client"
	case identitypb.UserRole_USER_ROLE_RESOURCE:
		return "resource"
	default:
		return "unspecified"
	}
}

func tenantTypeName(t identitypb.TenantType) string {
	switch t {
	case identitypb.TenantType_TENANT_TYPE_INDIVIDUAL:
		return "individual"
	case identitypb.TenantType_TENANT_TYPE_ORG:
		return "org"
	default:
		return "unspecified"
	}
}

func (h *Handler) issueToken(w http.ResponseWriter, user *identitypb.User) {
	token, err := h.Issuer.Issue(user)
	if err != nil {
		util.WriteJSON(w, map[string]string{"code": "INTERNAL", "message": err.Error()}, http.StatusInternalServerError)
		return
	}
	util.WriteJSON(w, map[string]interface{}{"user": user, "jwt": token}, http.StatusOK)
}

func (h *Handler) RegisterClient(w http.ResponseWriter, r *http.Request) {
	req := new(identitypb.RegisterClientRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, http.StatusBadRequest)
		return
	}
	resp, e := h.Identity.RegisterClient(r.Context(), req)
	if e != nil {
		call(w, resp, e)
		return
	}
	h.issueToken(w, resp.User)
}

func (h *Handler) RegisterResource(w http.ResponseWriter, r *http.Request) {
	body, err := io.ReadAll(r.Body)
	if err != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": err.Error()}, 400)
		return
	}
	accountReq := new(identitypb.RegisterProviderRequest)
	resourceReq := new(resourcepb.CreateResourceRequest)
	opts := protojson.UnmarshalOptions{DiscardUnknown: true}
	if err := opts.Unmarshal(body, accountReq); err != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": err.Error()}, 400)
		return
	}
	if err := opts.Unmarshal(body, resourceReq); err != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": err.Error()}, 400)
		return
	}
	accountResp, err := h.Identity.RegisterProvider(r.Context(), accountReq)
	if err != nil {
		call(w, accountResp, err)
		return
	}
	if accountResp == nil || accountResp.User == nil {
		util.WriteJSON(w, map[string]string{"code": "INTERNAL", "message": "resource account registration returned no user"}, 500)
		return
	}
	resourceReq.UserId = accountResp.User.UserId
	if accountResp.User.TenantType == identitypb.TenantType_TENANT_TYPE_ORG && accountResp.User.OrgId != nil {
		resourceReq.TenantType = resourcepb.TenantType_TENANT_TYPE_ORG
		resourceReq.OrgId = accountResp.User.OrgId
	} else {
		resourceReq.TenantType = resourcepb.TenantType_TENANT_TYPE_INDIVIDUAL
		resourceReq.OrgId = nil
	}
	resourceResp, err := h.Resource.CreateResource(r.Context(), resourceReq)
	if err != nil {
		_, _ = h.Identity.SetUserStatus(r.Context(), &identitypb.SetUserStatusRequest{UserId: accountResp.User.UserId, IsActive: false})
		call(w, resourceResp, err)
		return
	}
	util.WriteJSON(w, map[string]interface{}{"user": accountResp.User, "resource_id": resourceResp.GetResourceId()}, http.StatusOK)
}

func (h *Handler) LoginResource(w http.ResponseWriter, r *http.Request) {
	req := new(identitypb.LoginRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, http.StatusBadRequest)
		return
	}
	resp, e := h.Identity.Login(r.Context(), req)
	if e != nil {
		call(w, resp, e)
		return
	}
	if resp.User == nil || resp.User.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		writeForbidden(w, "resource login is only available to resource accounts")
		return
	}
	h.issueToken(w, resp.User)
}

func (h *Handler) LoginClient(w http.ResponseWriter, r *http.Request) {
	req := new(identitypb.LoginRequest)

	if e := decode(r, req); e != nil {
		util.WriteJSON(
			w,
			map[string]string{
				"code":    "INVALID_ARGUMENT",
				"message": e.Error(),
			},
			http.StatusBadRequest,
		)
		return
	}

	resp, e := h.Identity.Login(r.Context(), req)
	if e != nil {
		call(w, resp, e)
		return
	}

	if resp.User.Role != identitypb.UserRole_USER_ROLE_CLIENT {
		writeForbidden(w, "invalid account type for this login")
		return
	}

	h.issueToken(w, resp.User)
}

func (h *Handler) UpdateProfile(w http.ResponseWriter, r *http.Request) {
	req := new(identitypb.UpdateProfileRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	p, _ := middleware.PrincipalFromContext(r.Context())
	req.UserId = p.UserID
	resp, e := h.Identity.UpdateProfile(meta(r), req)
	call(w, resp, e)
}
func (h *Handler) GetUser(w http.ResponseWriter, r *http.Request) {
	p, _ := middleware.PrincipalFromContext(r.Context())
	resp, e := h.Identity.GetUser(meta(r), &identitypb.GetUserRequest{UserId: p.UserID})
	call(w, resp, e)
}

func writeForbidden(w http.ResponseWriter, message string) {
	util.WriteJSON(w, map[string]string{"code": "PERMISSION_DENIED", "message": message}, http.StatusForbidden)
}

func (h *Handler) CreateResource(w http.ResponseWriter, r *http.Request) {
	req := new(resourcepb.CreateResourceRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, http.StatusBadRequest)
		return
	}
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok || p.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		writeForbidden(w, "only resource accounts can manage resources")
		return
	}
	req.UserId = p.UserID
	if p.TenantType == identitypb.TenantType_TENANT_TYPE_ORG {
		req.TenantType = resourcepb.TenantType_TENANT_TYPE_ORG
		if p.OrgID == "" {
			writeForbidden(w, "organization context is required")
			return
		}
		orgId := p.OrgID
		req.OrgId = &orgId
	} else {
		req.TenantType = resourcepb.TenantType_TENANT_TYPE_INDIVIDUAL
		req.OrgId = nil
	}
	resp, e := h.Resource.CreateResource(meta(r), req)
	call(w, resp, e)
}

func (h *Handler) UpdateResource(w http.ResponseWriter, r *http.Request) {
	req := new(resourcepb.UpdateResourceRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{
			"code":    "INVALID_ARGUMENT",
			"message": e.Error(),
		}, http.StatusBadRequest)
		return
	}
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok || p.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		writeForbidden(w, "only resource accounts can update their resource profile")
		return
	}
	if p.TenantType == identitypb.TenantType_TENANT_TYPE_ORG {
		req.TenantType = resourcepb.TenantType_TENANT_TYPE_ORG
		orgID := p.OrgID
		req.OrgId = &orgID
	} else {
		req.TenantType = resourcepb.TenantType_TENANT_TYPE_INDIVIDUAL
		req.OrgId = nil
	}
	resp, e := h.Resource.UpdateResource(r.Context(), req)
	call(w, resp, e)
}

func (h *Handler) GetMyResource(w http.ResponseWriter, r *http.Request) {
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok || p.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		writeForbidden(w, "only resource accounts can view their resource profile")
		return
	}

	lookup, e := h.Resource.SearchResources(meta(r), &resourcepb.SearchResourcesRequest{
		Attributes: map[string]string{"__user_id": p.UserID},
	})
	if e != nil {
		call(w, lookup, e)
		return
	}
	if len(lookup.GetResources()) == 0 {
		util.WriteJSON(w, map[string]string{"code": "NOT_FOUND", "message": "resource profile not found"}, http.StatusNotFound)
		return
	}

	resourceID := lookup.Resources[0].GetResourceId()
	resource, e := h.Resource.GetResourceById(meta(r), &resourcepb.GetResourceByIdRequest{
		ResourceId: resourceID,
	})
	if e != nil {
		call(w, resource, e)
		return
	}

	response := map[string]interface{}{"resource": resource.GetResource()}
	if resource.GetResource() != nil && resource.GetResource().GetOrgId() != "" {
		if orgResp, orgErr := h.Identity.GetOrganization(meta(r), &identitypb.GetOrganizationRequest{
			OrganizationId: resource.GetResource().GetOrgId(),
		}); orgErr == nil && orgResp != nil && orgResp.Organization != nil {
			response["organization"] = orgResp.Organization
		}
	}
	if resource.GetAttributes() != nil {
		response["attributes"] = resource.GetAttributes()
	}
	util.WriteJSON(w, response, http.StatusOK)
}

func (h *Handler) GetResourceById(w http.ResponseWriter, r *http.Request) {
	resourceID := resourceIDPath(r.URL.Path)
	if resourceID == "" {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": "resource id is required"}, http.StatusBadRequest)
		return
	}

	resp, e := h.Resource.GetResourceById(r.Context(), &resourcepb.GetResourceByIdRequest{
		ResourceId: resourceID,
	})
	call(w, resp, e)
}

func optionalUnixQuery(r *http.Request, key string) (*int64, error) {
	value := strings.TrimSpace(r.URL.Query().Get(key))
	if value == "" {
		return nil, nil
	}
	unix, err := strconv.ParseInt(value, 10, 64)
	if err != nil || unix <= 0 {
		return nil, fmt.Errorf("%s must be a positive unix timestamp", key)
	}
	return &unix, nil
}

func (h *Handler) GetSlotsByResourceId(w http.ResponseWriter, r *http.Request) {
	resourceID := resourceIDPath(r.URL.Path)
	if resourceID == "" {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": "resource id is required"}, http.StatusBadRequest)
		return
	}

	startUnix, err := optionalUnixQuery(r, "start_unix")
	if err != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": err.Error()}, http.StatusBadRequest)
		return
	}
	endUnix, err := optionalUnixQuery(r, "end_unix")
	if err != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": err.Error()}, http.StatusBadRequest)
		return
	}
	if (startUnix == nil) != (endUnix == nil) {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": "start_unix and end_unix must be provided together"}, http.StatusBadRequest)
		return
	}
	if startUnix != nil && *endUnix <= *startUnix {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": "end_unix must be after start_unix"}, http.StatusBadRequest)
		return
	}

	resp, e := h.Resource.GetSlotsByResourceId(r.Context(), &resourcepb.GetSlotsByResourceIdRequest{
		ResourceId: resourceID,
		StartUnix:  startUnix,
		EndUnix:    endUnix,
	})
	call(w, resp, e)
}

func (h *Handler) SearchResources(w http.ResponseWriter, r *http.Request) {
	req := new(resourcepb.SearchResourcesRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	resp, e := h.Resource.SearchResources(r.Context(), req)
	call(w, resp, e)
}

func (h *Handler) GetSlot(w http.ResponseWriter, r *http.Request) {
	resp, e := h.Resource.GetSlot(r.Context(), &resourcepb.GetSlotRequest{SlotId: pathID(r.URL.Path)})
	call(w, resp, e)
}

func (h *Handler) CreateBooking(w http.ResponseWriter, r *http.Request) {
	req := new(bookingpb.CreateBookingRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	if !h.resourceSlotExists(r, req.GetResourceId(), req.GetStartUnix(), req.GetEndUnix()) {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": "the selected time is not an available slot for this resource"}, http.StatusBadRequest)
		return
	}
	p, _ := middleware.PrincipalFromContext(r.Context())
	req.UserId = p.UserID

	var clientUser *identitypb.User
	if userResp, userErr := h.Identity.GetUser(meta(r), &identitypb.GetUserRequest{UserId: p.UserID}); userErr == nil && userResp != nil {
		clientUser = userResp.GetUser()
		if clientUser != nil && clientUser.Identifier != nil {
			req.UserEmail = clientUser.Identifier.GetEmail()
		}
	}

	booking := &bookingpb.GetBookingStatusResponse{
		UserId: req.GetUserId(), ResourceId: req.GetResourceId(),
		StartUnix: req.GetStartUnix(), EndUnix: req.GetEndUnix(),
		Title: req.GetTitle(), Subtitle: req.GetSubtitle(),
	}
	ctx := h.withBookingNotificationContext(r, booking, clientUser)
	resp, e := h.Booking.CreateBooking(ctx, req)
	call(w, resp, e)
}

func (h *Handler) withBookingNotificationContext(r *http.Request, booking *bookingpb.GetBookingStatusResponse, clientUser *identitypb.User) context.Context {
	ctx := meta(r)
	if booking == nil {
		return ctx
	}

	if clientUser == nil && booking.GetUserId() != "" {
		if resp, err := h.Identity.GetUser(meta(r), &identitypb.GetUserRequest{UserId: booking.GetUserId()}); err == nil && resp != nil {
			clientUser = resp.GetUser()
		}
	}

	clientName := ""
	clientEmail := ""
	if clientUser != nil {
		clientName = clientUser.GetName()
		if clientUser.GetIdentifier() != nil {
			clientEmail = clientUser.GetIdentifier().GetEmail()
		}
	}

	resourceName := ""
	resourceEmail := ""
	meetingMode := ""
	address := ""

	if booking.GetResourceId() != "" {
		resp, err := h.Resource.GetResourceById(meta(r), &resourcepb.GetResourceByIdRequest{
			ResourceId: booking.GetResourceId(),
		})
		if err == nil && resp != nil && resp.GetResource() != nil {
			resource := resp.GetResource()
			resourceName = resource.GetName()
			meetingMode = strings.TrimPrefix(resource.GetMeetingMode().String(), "MEETING_MODE_")
			meetingMode = strings.ToLower(meetingMode)
			attrs := resp.GetAttributes()
			if attrs != nil {
				address = strings.TrimSpace(attrs["address"])
				resourceEmail = strings.TrimSpace(attrs["resource_email"])
				if resourceEmail == "" {
					resourceEmail = strings.TrimSpace(attrs["email"])
				}
			}
		}
	}

	return metadata.AppendToOutgoingContext(
		ctx,
		"x-booking-client-name", clientName,
		"x-booking-client-email", clientEmail,
		"x-booking-resource-name", resourceName,
		"x-booking-resource-email", resourceEmail,
		"x-booking-meeting-mode", meetingMode,
		"x-booking-address", address,
	)
}

func (h *Handler) resourceSlotExists(r *http.Request, resourceID string, startUnix, endUnix int64) bool {
	if resourceID == "" || startUnix <= 0 || endUnix <= startUnix {
		return false
	}

	resp, err := h.Resource.GetSlotsByResourceId(meta(r), &resourcepb.GetSlotsByResourceIdRequest{
		ResourceId: resourceID,
		StartUnix:  &startUnix,
		EndUnix:    &endUnix,
	})
	if err != nil || resp == nil {
		return false
	}

	for _, slot := range resp.GetSlots() {
		if slot == nil || slot.GetSlotTiming() == nil {
			continue
		}
		if slot.GetSlotTiming().GetStartUnix() == startUnix && slot.GetSlotTiming().GetEndUnix() == endUnix &&
			slot.GetStatus() == resourcepb.SlotStatus_SLOT_STATUS_OPEN {
			return true
		}
	}
	return false
}

func (h *Handler) CancelBooking(w http.ResponseWriter, r *http.Request) {
	ref := bookingReferencePath(r.URL.Path)
	if ref == "" {
		writeForbidden(w, "invalid booking reference")
		return
	}

	if !h.canAccessBooking(r, ref) {
		writeForbidden(w, "you do not have access to this booking")
		return
	}

	current, _ := h.Booking.GetBookingStatus(meta(r), &bookingpb.GetBookingStatusRequest{ReferenceCode: ref})
	ctx := h.withBookingNotificationContext(r, current, nil)
	resp, e := h.Booking.CancelBooking(
		ctx,
		&bookingpb.CancelBookingRequest{
			ReferenceCode: ref,
		},
	)
	call(w, resp, e)
}
func (h *Handler) RescheduleBooking(w http.ResponseWriter, r *http.Request) {
	req := new(bookingpb.RescheduleBookingRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(
			w,
			map[string]string{
				"code":    "INVALID_ARGUMENT",
				"message": e.Error(),
			},
			http.StatusBadRequest,
		)
		return
	}
	req.ReferenceCode = bookingReferencePath(r.URL.Path)
	if req.ReferenceCode == "" {
		util.WriteJSON(
			w,
			map[string]string{
				"code":    "INVALID_ARGUMENT",
				"message": "invalid booking reference",
			},
			http.StatusBadRequest,
		)
		return
	}
	if !h.canAccessBooking(r, req.ReferenceCode) {
		writeForbidden(w, "you do not have access to this booking")
		return
	}
	if req.StartUnix <= 0 || req.EndUnix <= req.StartUnix {
		util.WriteJSON(
			w,
			map[string]string{
				"code":    "INVALID_ARGUMENT",
				"message": "invalid reschedule time window",
			},
			http.StatusBadRequest,
		)
		return
	}
	current, e := h.Booking.GetBookingStatus(
		meta(r),
		&bookingpb.GetBookingStatusRequest{
			ReferenceCode: req.ReferenceCode,
		},
	)
	if e != nil || current == nil ||
		!h.resourceSlotExists(
			r,
			current.GetResourceId(),
			req.GetStartUnix(),
			req.GetEndUnix(),
		) {
		util.WriteJSON(
			w,
			map[string]string{
				"code":    "INVALID_ARGUMENT",
				"message": "the selected time is not an available slot for this resource",
			},
			http.StatusBadRequest,
		)
		return
	}
	ctx := h.withBookingNotificationContext(r, current, nil)
	ctx = metadata.AppendToOutgoingContext(
		ctx,
		"x-booking-previous-start", strconv.FormatInt(current.GetStartUnix(), 10),
		"x-booking-previous-end", strconv.FormatInt(current.GetEndUnix(), 10),
	)
	resp, e := h.Booking.RescheduleBooking(ctx, req)
	call(w, resp, e)
}

func (h *Handler) canAccessBooking(r *http.Request, reference string) bool {
	booking, err := h.Booking.GetBookingStatus(meta(r), &bookingpb.GetBookingStatusRequest{ReferenceCode: reference})
	if err != nil || booking == nil {
		return false
	}
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok {
		return false
	}
	switch p.Role {
	case identitypb.UserRole_USER_ROLE_CLIENT:
		return booking.GetUserId() == p.UserID
	case identitypb.UserRole_USER_ROLE_RESOURCE:
		// Resolve the exact resource owned by this account. The old check only
		// looked at the first resource returned by SearchResources, which could
		// fail when the search/cache result did not line up with the booking.
		lookup, err := h.Resource.SearchResources(meta(r), &resourcepb.SearchResourcesRequest{
			Attributes: map[string]string{
				"__user_id":     p.UserID,
				"__resource_id": booking.GetResourceId(),
			},
		})
		return err == nil && len(lookup.GetResources()) == 1 && lookup.Resources[0].GetResourceId() == booking.GetResourceId()
	default:
		return false
	}
}
func bookingReferencePath(path string) string {
	parts := strings.Split(strings.Trim(path, "/"), "/")
	for i := 0; i+1 < len(parts); i++ {
		if parts[i] == "bookings" {
			return parts[i+1]
		}
	}
	return ""
}
func (h *Handler) ListUpcomingBookings(w http.ResponseWriter, r *http.Request) {
	p, _ := middleware.PrincipalFromContext(r.Context())
	resp, e := h.Booking.ListUpcomingBookings(meta(r), &bookingpb.ListUserBookingsRequest{UserId: p.UserID})
	h.writeBookingList(w, r, resp, e)
}

func (h *Handler) ListPastBookings(w http.ResponseWriter, r *http.Request) {
	p, _ := middleware.PrincipalFromContext(r.Context())
	resp, e := h.Booking.ListPastBookings(meta(r), &bookingpb.ListUserBookingsRequest{UserId: p.UserID})
	h.writeBookingList(w, r, resp, e)
}

func (h *Handler) ListResourceUpcomingBookings(w http.ResponseWriter, r *http.Request) {
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok || p.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		writeForbidden(w, "only resource accounts can view resource bookings")
		return
	}
	lookup := &resourcepb.SearchResourcesRequest{Attributes: map[string]string{"__user_id": p.UserID}}
	resources, e := h.Resource.SearchResources(meta(r), lookup)
	if e != nil {
		call(w, resources, e)
		return
	}
	if len(resources.GetResources()) == 0 {
		util.WriteJSON(w, map[string]string{"code": "NOT_FOUND", "message": "resource profile not found"}, 404)
		return
	}
	ctx := metadata.AppendToOutgoingContext(meta(r), "x-list-scope", "resource")
	resp, e := h.Booking.ListUpcomingBookings(ctx, &bookingpb.ListUserBookingsRequest{UserId: resources.Resources[0].ResourceId})
	h.writeBookingList(w, r, resp, e)
}

func (h *Handler) ListResourcePastBookings(w http.ResponseWriter, r *http.Request) {
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok || p.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		writeForbidden(w, "only resource accounts can view resource events")
		return
	}

	lookup := &resourcepb.SearchResourcesRequest{
		Attributes: map[string]string{"__user_id": p.UserID},
	}
	resources, e := h.Resource.SearchResources(meta(r), lookup)
	if e != nil {
		call(w, resources, e)
		return
	}
	if len(resources.GetResources()) == 0 {
		util.WriteJSON(w, map[string]string{"code": "NOT_FOUND", "message": "resource profile not found"}, http.StatusNotFound)
		return
	}

	ctx := metadata.AppendToOutgoingContext(meta(r), "x-list-scope", "resource")
	resp, e := h.Booking.ListPastBookings(ctx, &bookingpb.ListUserBookingsRequest{
		UserId: resources.Resources[0].ResourceId,
	})
	h.writeBookingList(w, r, resp, e)
}

func (h *Handler) GetBooking(w http.ResponseWriter, r *http.Request) {
	ref := pathID(r.URL.Path)
	if !h.canAccessBooking(r, ref) {
		writeForbidden(w, "you do not have access to this booking")
		return
	}
	resp, e := h.Booking.GetBookingStatus(meta(r), &bookingpb.GetBookingStatusRequest{ReferenceCode: ref})
	h.writeBookingList(w, r, &bookingpb.ListUserBookingsResponse{Bookings: []*bookingpb.GetBookingStatusResponse{resp}}, e)
}
func (h *Handler) writeBookingList(w http.ResponseWriter, r *http.Request, resp *bookingpb.ListUserBookingsResponse, err error) {
	if err != nil {
		util.WriteGRPCError(w, err)
		return
	}
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok {
		writeForbidden(w, "authentication required")
		return
	}

	rescheduledByRef := make(map[string]*bookingpb.GetBookingStatusResponse)
	for _, booking := range resp.GetBookings() {
		if booking == nil {
			continue
		}
		if booking.GetStatus().String() == "BOOKING_STATUS_RESCHEDULED" {
			rescheduledByRef[booking.GetReferenceCode()] = booking
		}
	}

	views := make([]interface{}, 0, len(resp.GetBookings()))
	seen := make(map[string]bool)
	nowUnix := time.Now().Unix()
	for _, booking := range resp.GetBookings() {
		if booking == nil || seen[booking.GetReferenceCode()] {
			continue
		}

		current := booking
		statusText := booking.GetStatus().String()
		var previousStart, previousEnd int64

		if booking.GetStatus().String() == "BOOKING_STATUS_RESCHEDULED" {
			latest, latestErr := h.Booking.GetBookingStatus(meta(r), &bookingpb.GetBookingStatusRequest{ReferenceCode: booking.GetReferenceCode()})
			if latestErr == nil && latest != nil {
				if latest.GetStartUnix() >= nowUnix && booking.GetStartUnix() < nowUnix {
					seen[booking.GetReferenceCode()] = true
					continue
				}
				current = latest
				previousStart = booking.GetStartUnix()
				previousEnd = booking.GetEndUnix()
			}
			statusText = "BOOKING_STATUS_RESCHEDULED"
		} else if prior := rescheduledByRef[booking.GetReferenceCode()]; prior != nil {
			previousStart = prior.GetStartUnix()
			previousEnd = prior.GetEndUnix()
			statusText = "BOOKING_STATUS_RESCHEDULED"
		}

		view := map[string]interface{}{
			"reference_code": current.GetReferenceCode(),
			"user_id":        current.GetUserId(),
			"resource_id":    current.GetResourceId(),
			"start_unix":     current.GetStartUnix(),
			"end_unix":       current.GetEndUnix(),
			"title":          current.GetTitle(),
			"subtitle":       current.GetSubtitle(),
			"status":         statusText,
		}
		if previousStart > 0 {
			view["previous_start_unix"] = previousStart
			view["previous_end_unix"] = previousEnd
		}

		resourceResp, resourceErr := h.Resource.GetResourceById(meta(r), &resourcepb.GetResourceByIdRequest{
			ResourceId: current.GetResourceId(),
		})
		if resourceErr == nil && resourceResp != nil && resourceResp.GetResource() != nil {
			resource := resourceResp.GetResource()
			view["resource_name"] = resource.GetName()
			view["meeting_mode"] = resource.GetMeetingMode().String()
			if address := resourceResp.GetAttributes()["address"]; address != "" {
				view["address"] = address
			}
			if p.Role == identitypb.UserRole_USER_ROLE_CLIENT {
				view["display_title"] = "Meeting with " + resource.GetName()
			}
		}

		if p.Role == identitypb.UserRole_USER_ROLE_RESOURCE {
			if userResp, userErr := h.Identity.GetUser(meta(r), &identitypb.GetUserRequest{UserId: current.GetUserId()}); userErr == nil && userResp != nil && userResp.GetUser() != nil {
				view["client_name"] = userResp.GetUser().GetName()
				view["display_title"] = "Meeting with " + userResp.GetUser().GetName()
			}
		}

		seen[booking.GetReferenceCode()] = true
		views = append(views, view)
	}
	util.WriteJSON(w, map[string]interface{}{"bookings": views}, http.StatusOK)
}

func pathID(path string) string {
	parts := strings.Split(strings.Trim(path, "/"), "/")
	if len(parts) == 0 {
		return ""
	}
	return parts[len(parts)-1]
}

func resourceIDPath(path string) string {
	parts := strings.Split(strings.Trim(path, "/"), "/")
	for i := 0; i+1 < len(parts); i++ {
		if parts[i] == "resources" {
			return parts[i+1]
		}
	}
	return ""
}

func (h *Handler) CreateOrganization(w http.ResponseWriter, r *http.Request) {
	req := new(identitypb.CreateOrganizationRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	resp, e := h.Identity.CreateOrganization(r.Context(), req)
	call(w, resp, e)
}

func (h *Handler) ListOrganizations(w http.ResponseWriter, r *http.Request) {
	resp, e := h.Identity.ListOrganizations(r.Context(), &identitypb.ListOrganizationsRequest{})
	call(w, resp, e)
}

func (h *Handler) GetOrganization(w http.ResponseWriter, r *http.Request) {
	resp, e := h.Identity.GetOrganization(r.Context(), &identitypb.GetOrganizationRequest{OrganizationId: pathID(r.URL.Path)})
	call(w, resp, e)
}

func (h *Handler) ListResourceTypes(w http.ResponseWriter, r *http.Request) {
	resp, e := h.Resource.ListResourceTypes(r.Context(), &resourcepb.ListResourceTypesRequest{})
	call(w, resp, e)
}

func (h *Handler) CreateResourceType(w http.ResponseWriter, r *http.Request) {
	req := new(resourcepb.CreateResourceTypeRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	resp, e := h.Resource.CreateResourceType(r.Context(), req)
	call(w, resp, e)
}

func (h *Handler) ownsResource(r *http.Request, resourceID string) bool {
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok || p.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		return false
	}
	lookup, err := h.Resource.SearchResources(meta(r), &resourcepb.SearchResourcesRequest{Attributes: map[string]string{"__user_id": p.UserID}})
	return err == nil && len(lookup.GetResources()) > 0 && lookup.Resources[0].ResourceId == resourceID
}

func (h *Handler) SetResourceStatus(w http.ResponseWriter, r *http.Request) {
	req := new(resourcepb.SetResourceStatusRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	req.ResourceId = pathID(r.URL.Path)
	p, _ := middleware.PrincipalFromContext(r.Context())
	// A resource may only mutate its own resource profile.
	lookup, e := h.Resource.SearchResources(meta(r), &resourcepb.SearchResourcesRequest{Attributes: map[string]string{"__user_id": p.UserID}})
	if e != nil {
		call(w, lookup, e)
		return
	}
	if len(lookup.GetResources()) == 0 || lookup.Resources[0].ResourceId != req.ResourceId {
		writeForbidden(w, "resource access denied")
		return
	}
	resp, e := h.Resource.SetResourceStatus(meta(r), req)
	if e != nil {
		call(w, resp, e)
		return
	}
	if lookup.Resources[0].OrgId != nil {
		orgID := lookup.Resources[0].OrgId
		activeLookup, _ := h.Resource.SearchResources(meta(r), &resourcepb.SearchResourcesRequest{OrgId: orgID})
		if activeLookup != nil {
			_, _ = h.Identity.SetOrganizationStatus(meta(r), &identitypb.SetOrganizationStatusRequest{OrganizationId: *orgID, IsActive: len(activeLookup.Resources) > 0})
		}
	}
	call(w, resp, e)
}

func (h *Handler) DeleteResource(w http.ResponseWriter, r *http.Request) {
	resp, e := h.Resource.DeleteResource(meta(r), &resourcepb.DeleteResourceRequest{ResourceId: pathID(r.URL.Path)})
	call(w, resp, e)
}

func (h *Handler) GetResourceAvailability(w http.ResponseWriter, r *http.Request) {
	resourceID := resourceIDPath(r.URL.Path)
	if resourceID == "" {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": "resource id is required"}, http.StatusBadRequest)
		return
	}
	startUnix, _ := strconv.ParseInt(r.URL.Query().Get("start_unix"), 10, 64)
	endUnix, _ := strconv.ParseInt(r.URL.Query().Get("end_unix"), 10, 64)
	if startUnix <= 0 || endUnix <= startUnix {
		now := time.Now()
		startUnix = now.Unix()
		endUnix = now.AddDate(0, 0, 7).Unix()
	}

	resp, err := h.Resource.GetSlotsByResourceId(meta(r), &resourcepb.GetSlotsByResourceIdRequest{
		ResourceId: resourceID,
		StartUnix:  &startUnix,
		EndUnix:    &endUnix,
	})
	if err != nil {
		call(w, resp, err)
		return
	}

	type calendarSlot struct {
		StartUnix int64  `json:"start_unix"`
		EndUnix   int64  `json:"end_unix"`
		Status    string `json:"status"`
	}
	open := make(map[string]calendarSlot)
	for _, slot := range resp.GetSlots() {
		if slot == nil || slot.GetSlotTiming() == nil {
			continue
		}
		start := slot.GetSlotTiming().GetStartUnix()
		end := slot.GetSlotTiming().GetEndUnix()
		if start <= 0 || end <= start {
			continue
		}
		status := "available"
		if slot.GetStatus() != resourcepb.SlotStatus_SLOT_STATUS_OPEN {
			continue
		}
		key := fmt.Sprintf("%d-%d", start, end)
		open[key] = calendarSlot{StartUnix: start, EndUnix: end, Status: status}
	}

	ctx := metadata.AppendToOutgoingContext(meta(r), "x-list-scope", "resource")
	upcoming, upErr := h.Booking.ListUpcomingBookings(ctx, &bookingpb.ListUserBookingsRequest{UserId: resourceID})
	past, pastErr := h.Booking.ListPastBookings(ctx, &bookingpb.ListUserBookingsRequest{UserId: resourceID})
	if upErr != nil || pastErr != nil {
		if upErr != nil {
			util.WriteGRPCError(w, upErr)
		} else {
			util.WriteGRPCError(w, pastErr)
		}
		return
	}

	for _, list := range []*bookingpb.ListUserBookingsResponse{upcoming, past} {
		for _, booking := range list.GetBookings() {
			if booking == nil || booking.GetResourceId() != resourceID {
				continue
			}
			status := booking.GetStatus().String()
			if status != "BOOKING_STATUS_CONFIRMED" && status != "BOOKING_STATUS_WAITLISTED" {
				continue
			}
			if booking.GetStartUnix() < startUnix || booking.GetStartUnix() >= endUnix {
				continue
			}
			key := fmt.Sprintf("%d-%d", booking.GetStartUnix(), booking.GetEndUnix())
			if _, exists := open[key]; exists {
				open[key] = calendarSlot{StartUnix: booking.GetStartUnix(), EndUnix: booking.GetEndUnix(), Status: "booked"}
			}
		}
	}

	slots := make([]calendarSlot, 0, len(open))
	for _, slot := range open {
		slots = append(slots, slot)
	}
	sort.Slice(slots, func(i, j int) bool { return slots[i].StartUnix < slots[j].StartUnix })
	util.WriteJSON(w, map[string]interface{}{"slots": slots}, http.StatusOK)
}

func (h *Handler) GetMyAvailability(w http.ResponseWriter, r *http.Request) {
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok || p.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		writeForbidden(w, "only resource accounts can view availability")
		return
	}

	lookup, err := h.Resource.SearchResources(meta(r), &resourcepb.SearchResourcesRequest{
		Attributes: map[string]string{"__user_id": p.UserID},
	})
	if err != nil {
		call(w, lookup, err)
		return
	}
	if len(lookup.GetResources()) == 0 {
		util.WriteJSON(w, map[string]string{"code": "NOT_FOUND", "message": "resource profile not found"}, http.StatusNotFound)
		return
	}

	resourceID := lookup.Resources[0].GetResourceId()
	resp, err := h.Resource.GetSlotsByResourceId(meta(r), &resourcepb.GetSlotsByResourceIdRequest{
		ResourceId: resourceID,
	})
	if err != nil {
		call(w, resp, err)
		return
	}
	util.WriteJSON(w, map[string]interface{}{"recurrence": resp.GetRecurrence()}, http.StatusOK)
}

func (h *Handler) SetRecurringAvailability(w http.ResponseWriter, r *http.Request) {
	resourceID := pathID(r.URL.Path)
	if !h.ownsResource(r, resourceID) {
		writeForbidden(w, "resource access denied")
		return
	}
	req := new(resourcepb.SetRecurringAvailabilityRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	req.ResourceId = resourceID
	resp, e := h.Resource.SetRecurringAvailability(meta(r), req)
	call(w, resp, e)
}

// SetMyRecurringAvailability resolves the resource from the authenticated
// user instead of trusting a resource id supplied by the browser. This keeps
// the ownership check tied to the JWT identity and avoids stale/mismatched ids
// in the profile UI.
func (h *Handler) SetMyRecurringAvailability(w http.ResponseWriter, r *http.Request) {
	p, ok := middleware.PrincipalFromContext(r.Context())
	if !ok || p.Role != identitypb.UserRole_USER_ROLE_RESOURCE {
		writeForbidden(w, "only resource accounts can manage availability")
		return
	}

	lookup, e := h.Resource.SearchResources(meta(r), &resourcepb.SearchResourcesRequest{
		Attributes: map[string]string{"__user_id": p.UserID},
	})
	if e != nil {
		call(w, lookup, e)
		return
	}
	if len(lookup.GetResources()) == 0 {
		writeForbidden(w, "resource profile not found")
		return
	}

	req := new(resourcepb.SetRecurringAvailabilityRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	req.ResourceId = lookup.Resources[0].ResourceId
	resp, e := h.Resource.SetRecurringAvailability(meta(r), req)
	call(w, resp, e)
}
func (h *Handler) AddSlotException(w http.ResponseWriter, r *http.Request) {
	if !h.ownsResource(r, pathID(r.URL.Path)) {
		writeForbidden(w, "resource access denied")
		return
	}
	req := new(resourcepb.AddSlotExceptionRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	req.ResourceId = pathID(r.URL.Path)
	resp, e := h.Resource.AddSlotException(meta(r), req)
	call(w, resp, e)
}
func (h *Handler) RemoveSlotException(w http.ResponseWriter, r *http.Request) {
	req := new(resourcepb.RemoveSlotExceptionRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	req.SlotId = pathID(r.URL.Path)
	resp, e := h.Resource.RemoveSlotException(meta(r), req)
	call(w, resp, e)
}
func (h *Handler) SetLeavePeriod(w http.ResponseWriter, r *http.Request) {
	if !h.ownsResource(r, pathID(r.URL.Path)) {
		writeForbidden(w, "resource access denied")
		return
	}
	req := new(resourcepb.SetLeavePeriodRequest)
	if e := decode(r, req); e != nil {
		util.WriteJSON(w, map[string]string{"code": "INVALID_ARGUMENT", "message": e.Error()}, 400)
		return
	}
	req.ResourceId = pathID(r.URL.Path)
	resp, e := h.Resource.SetLeavePeriod(meta(r), req)
	call(w, resp, e)
}
